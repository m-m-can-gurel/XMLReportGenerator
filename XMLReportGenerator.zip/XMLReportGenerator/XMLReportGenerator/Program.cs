﻿using System;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Xml;
using System.Xml.Linq;

namespace XMLReportGenerator
{
    class Program
    {
        
        private class ValueFactor
        {
            public decimal High { get; set; }
            public decimal Medium { get; set; }
            public decimal Low { get; set; }
        }

        private class EmmissionsFactor
        {
            public decimal High { get; set; }
            public decimal Medium { get; set; }
            public decimal Low { get; set; }
        }

        static int Main(string[] args)
        {
            try
            {
                string InputFolderPath = ConfigurationManager.AppSettings["InputFolderPath"];
                string OutputFolderPath = ConfigurationManager.AppSettings["OutputFolderPath"];
                string StatisticalDataFilePath = ConfigurationManager.AppSettings["StatisticalDataFilePath"];

                if (!Directory.Exists(InputFolderPath))
                {
                    LogError($"Directory configured for new input files {InputFolderPath} does not exists.");
                    return (-1);
                }

                if (!Directory.Exists(OutputFolderPath))
                {
                    LogError($"Directory configured for new output files {OutputFolderPath} does not exists.");
                    return (-1);
                }

                if (!File.Exists(StatisticalDataFilePath))
                {
                    LogError($"File configured for statistical data {StatisticalDataFilePath} does not exists.");
                    return (-1);
                }


                var valueFactor = new ValueFactor();
                var emmissionsFactor = new EmmissionsFactor();

                var gotStatisticalData = GetStatisticalData(StatisticalDataFilePath, out valueFactor, out emmissionsFactor);
                if (!gotStatisticalData)
                    return -1;

                LogInfo($"Looking for new files to process under directory {InputFolderPath}.");

                while (true)
                {
                    string[] files = Directory.GetFiles(InputFolderPath);
                    foreach (string file in files)
                    {
                        var inputFileName = Path.GetFileNameWithoutExtension(file);
                        var reportFile = OutputFolderPath + "\\" + inputFileName + "-Result.xml";
                        if (!File.Exists(reportFile))
                        {
                            var processedXml = ProcessFile(file, valueFactor, emmissionsFactor);
                            processedXml.Save(reportFile);
                        }
                    }

                    System.Threading.Thread.Sleep(1000);
                }
            } catch (Exception e)
            {
                LogError(e.Message);
                if (e.InnerException != null)
                    LogError(e.InnerException.Message);
                LogError(e.StackTrace);
                return -1;
            }
        }
        
        private static void LogInfo(string msg)
        {
            Console.WriteLine("INFO: " + msg);
        }
        
        private static void LogError(string msg)
        {
            Console.WriteLine("ERROR: " + msg);
        }

        private static bool GetStatisticalData(string StatisticalDataFilePath, out ValueFactor valueFactor, out EmmissionsFactor emmissionsFactor)
        {
            LogInfo($"Getting statistical data from file '{StatisticalDataFilePath}'.");
            XmlDocument xmlDoc = new XmlDocument();
            valueFactor =  new ValueFactor();
            emmissionsFactor = new EmmissionsFactor();

            try
            {
                xmlDoc.Load(StatisticalDataFilePath);
                valueFactor.High = Decimal.Parse(xmlDoc.DocumentElement.SelectSingleNode("/ReferenceData/Factors/ValueFactor/High").InnerText);
                valueFactor.Medium = Decimal.Parse(xmlDoc.DocumentElement.SelectSingleNode("/ReferenceData/Factors/ValueFactor/Medium").InnerText);
                valueFactor.Low = Decimal.Parse(xmlDoc.DocumentElement.SelectSingleNode("/ReferenceData/Factors/ValueFactor/Low").InnerText);

                emmissionsFactor.High = Decimal.Parse(xmlDoc.DocumentElement.SelectSingleNode("/ReferenceData/Factors/EmissionsFactor/High").InnerText);
                emmissionsFactor.Medium = Decimal.Parse(xmlDoc.DocumentElement.SelectSingleNode("/ReferenceData/Factors/EmissionsFactor/Medium").InnerText);
                emmissionsFactor.Low = Decimal.Parse(xmlDoc.DocumentElement.SelectSingleNode("/ReferenceData/Factors/EmissionsFactor/Low").InnerText);
            }
            catch (Exception e)
            {
                LogError($"Exception when getting statistical data from file '{StatisticalDataFilePath}'.");
                LogError(e.Message);
                if (e.InnerException != null)
                    LogError(e.InnerException.Message);
                LogError(e.StackTrace);
                return false;
            }
            
            LogInfo($"Completed getting statistical data from file '{StatisticalDataFilePath}'.");
            return true;
        }

        private static XmlDocument ProcessFile(string sourceFile, ValueFactor valueFactor, EmmissionsFactor emmissionsFactor)
        {
            LogInfo($"Processing file '{sourceFile}'.");
            XElement sourceXmlDoc = XElement.Load(sourceFile);

            XmlDocument resultXmlDoc = new XmlDocument();

            #region Declare fundamental XML elements
            XmlDeclaration xmlDeclaration = resultXmlDoc.CreateXmlDeclaration("1.0", "UTF-8", null);
            XmlElement root = resultXmlDoc.DocumentElement;
            resultXmlDoc.InsertBefore(xmlDeclaration, root);
            XmlElement generationOutputElement = resultXmlDoc.CreateElement("GenerationOutput");
            resultXmlDoc.AppendChild(generationOutputElement);

            XmlElement totalsElement = resultXmlDoc.CreateElement("Totals");
            generationOutputElement.AppendChild(totalsElement);

            XmlElement maxEmissionGeneratorsElement = resultXmlDoc.CreateElement("MaxEmissionGenerators");
            generationOutputElement.AppendChild(maxEmissionGeneratorsElement);

            XmlElement actualHeatRatesElement = resultXmlDoc.CreateElement("ActualHeatRates");
            generationOutputElement.AppendChild(actualHeatRatesElement);
            #endregion

            #region Calculate Totals & Actual Heat Rates
            var generationsList = sourceXmlDoc.Descendants("Generation");
            foreach (var generation in generationsList)
            {
                var daysList = generation.Elements("Day");
                decimal total = 0;
                foreach (var day in daysList)
                {
                    var energy = Decimal.Parse(day.Element("Energy").Value);
                    var price = Decimal.Parse(day.Element("Price").Value);
                    var value = energy * price;
                    if (generation.Parent.Name == "WindGenerator")
                    {
                        if (generation.Parent.Element("Location").Value == "Offshore")
                            value *= valueFactor.Low;
                        else if (generation.Parent.Element("Location").Value == "Onshore")
                            value *= valueFactor.High;
                        else
                            throw (new ApplicationException($"Unexpected wind generator location type {generation.Parent.Element("Location").Value}."));
                    }
                    else if ((generation.Parent.Name == "GasGenerator") || (generation.Parent.Name == "CoalGenerator"))
                        value *= valueFactor.Medium;
                    else
                        throw (new ApplicationException($"Unexpected wind generator type {generation.Parent.Name}."));
                    total += value;
                }

                XmlElement generatorElement = resultXmlDoc.CreateElement("Generator");
                totalsElement.AppendChild(generatorElement);
                XmlElement nameElement = resultXmlDoc.CreateElement("Name");
                nameElement.InnerText = generation.Parent.Element("Name").Value;
                generatorElement.AppendChild(nameElement);

                XmlElement totalElement = resultXmlDoc.CreateElement("Total");
                totalElement.InnerText = total.ToString();
                generatorElement.AppendChild(totalElement);

                if (generation.Parent.Elements("TotalHeatInput").Any() && generation.Parent.Elements("ActualNetGeneration").Any())
                {
                    var totalHeatInput = Decimal.Parse(generation.Parent.Element("TotalHeatInput").Value);
                    var actualNetGeneration = Decimal.Parse(generation.Parent.Element("ActualNetGeneration").Value);
                    var heatValue = totalHeatInput / actualNetGeneration;

                    XmlElement actualHeatRateElement = resultXmlDoc.CreateElement("ActualHeatRate");
                    actualHeatRatesElement.AppendChild(actualHeatRateElement);

                    XmlElement heatRateNameElement = resultXmlDoc.CreateElement("Name");
                    heatRateNameElement.InnerText = generation.Parent.Element("Name").Value;
                    actualHeatRateElement.AppendChild(heatRateNameElement);

                    XmlElement heatRateElement = resultXmlDoc.CreateElement("HeatRate");
                    heatRateElement.InnerText = heatValue.ToString();
                    actualHeatRateElement.AppendChild(heatRateElement);
                }
            }
            #endregion

            #region Calculate Max Emission Generators
            var orderedDays = sourceXmlDoc.Descendants("Day")
                                          .Where(x => x.Parent.Parent.Name == "GasGenerator" || x.Parent.Parent.Name == "CoalGenerator")
                                          .OrderBy(x => (DateTime) x.Element("Date"));
            DateTime previousDate = new DateTime();
            previousDate = DateTime.MinValue;
            string maxGeneratorName = "";
            decimal maxEmissionValue = 0;
            foreach (var day in orderedDays)
            {
                var date = DateTime.Parse(day.Element("Date").Value);
                if (day == orderedDays.First())
                    previousDate = date;
                if (date != previousDate || day == orderedDays.Last())
                {
                    XmlElement dayElement = resultXmlDoc.CreateElement("Day");
                    maxEmissionGeneratorsElement.AppendChild(dayElement);

                    XmlElement nameElement = resultXmlDoc.CreateElement("Name");
                    nameElement.InnerText = maxGeneratorName;
                    dayElement.AppendChild(nameElement);

                    XmlElement dateElement = resultXmlDoc.CreateElement("Date");
                    dateElement.InnerText = previousDate.ToString("yyyy-MM-ddTHH:mm:ssK");
                    dayElement.AppendChild(dateElement);

                    XmlElement emissionElement = resultXmlDoc.CreateElement("Emission");
                    emissionElement.InnerText = maxEmissionValue.ToString();
                    dayElement.AppendChild(emissionElement);

                    maxGeneratorName = "";
                    maxEmissionValue = 0;
                }
                var energy = Decimal.Parse(day.Element("Energy").Value);
                var rating = Decimal.Parse(day.Parent.Parent.Element("EmissionsRating").Value);
                var value = energy * rating;
                if (day.Parent.Parent.Name == "GasGenerator")
                    value *= emmissionsFactor.Medium;
                else if (day.Parent.Parent.Name == "CoalGenerator")
                    value *= emmissionsFactor.High;
                else
                    throw (new ApplicationException($"Unexpected wind generator type {day.Parent.Parent.Name}."));
                if (value > maxEmissionValue)
                {
                    maxGeneratorName = day.Parent.Parent.Element("Name").Value;
                    maxEmissionValue = value;
                }
                previousDate = date;
            }
            #endregion 

            LogInfo($"Completed processing file '{sourceFile}'.");

            return resultXmlDoc;
        }
    }
}
